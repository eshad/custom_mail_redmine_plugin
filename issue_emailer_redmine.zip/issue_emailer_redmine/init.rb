Redmine::Plugin.register :issue_emailer_redmine do
  name 'Issue Emailer Plugin'
  author 'Mehadi'
  description 'Adds a button to send email from an issue'
  version '0.0.1'
end